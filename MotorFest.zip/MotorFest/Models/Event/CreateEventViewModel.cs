﻿using MotorFest.Data.Entities;
using MotorFest.Models.Location;

namespace MotorFest.Models.Event
{
    public class CreateEventViewModel
    {
        public string Name { get; set; }

        public int LocationId { get; set; }
        public string OrganizerId { get; set; }
        public DateTime EventDate { get; set; } = DateTime.Now;

        public decimal EntranceFee { get; set; }

        public ICollection<CheckBoxItem> VehicleCategories { get; set; } = new List<CheckBoxItem>();
    }
}

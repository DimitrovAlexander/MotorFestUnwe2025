﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using MotorFest;
using MotorFest.Data;
using MotorFest.Data.Entities;
using MotorFest.Models.Event;
using MotorFest.Services.EventService;
using MotorFest.Services.LocationService;
using MotorFest.Services.VehicleCategoryService;

namespace MotorFest.Controllers
{
    public class EventsController : Controller
    {
        private readonly IEventService eventService;
        private readonly IVehicleCategoryService vehicleCategoryService;
        private readonly ILocationService locationService;
        private readonly UserManager<MFUser> _userManager;
        public EventsController(IEventService eventService, IVehicleCategoryService vehicleCategoryService, ILocationService locationService, UserManager<MFUser> userManager)
        {
            this.eventService = eventService;
            this.vehicleCategoryService = vehicleCategoryService;
            this.locationService = locationService;
            _userManager = userManager;
        }

        public async Task<IActionResult> Index()
        {
            var events = eventService.GetAll();
            return View(events);
        }

        [HttpGet]
        public async Task<IActionResult> Create()
        {
            var categories = vehicleCategoryService.GetAll();
                var user = await _userManager.GetUserAsync(User);
            var model = new EventViewModel
            {
                VehicleCategories = categories.Select(c => new CheckBoxItem
                {
                    Id = c.Id,
                    CategoryName = c.Name,
                    IsChecked = false
                }).ToList(),


            };
            ViewData["allLocations"] = locationService.GetAll()
       .Select(c => new SelectListItem
       {
           Value = c.Id.ToString(),
           Text = c.Name
       }).ToList();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Create(EventViewModel model)
        {
            ModelState.Remove("Location");
            ModelState.Remove("Organizer");
            ModelState.Remove("OrganizerId");
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var user = await _userManager.GetUserAsync(User);
            model.OrganizerId = user.Id;
            await eventService.Create(model);
            return RedirectToAction("Index");
        }

        public async Task<IActionResult> Details(int id)
        {
            var eventDetails = await eventService.GetById(id);
            if (eventDetails == null) return NotFound();
            return View(eventDetails);
        }

        public async Task<IActionResult> Delete(int id)
        {
            await eventService.Delete(id);
            return RedirectToAction("Index");
        }
    }
}

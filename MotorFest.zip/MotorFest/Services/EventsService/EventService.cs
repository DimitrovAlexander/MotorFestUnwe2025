﻿using MotorFest.Data.Entities;
using MotorFest.Data;
using MotorFest.Services.EventService;
using Microsoft.EntityFrameworkCore;
using MotorFest.Models.Event;
using MotorFest.Models.EventVehicleCategory;

namespace MotorFest.Services.EventsService
{
    public class EventService : IEventService
    {
        private readonly MotorFestDbContext _context;

        public EventService(MotorFestDbContext context)
        {
            _context = context;
        }

        public ICollection<EventViewModel> GetAll()
        {
            return _context.Events
                .Select(e => new EventViewModel
                {
                    Id = e.Id,
                    Name = e.Name,
                    OrganizerId = e.OrganizerId,
                    LocationId = e.LocationId,
                    EventDate = e.EventDate,
                    EntranceFee = e.EntranceFee,
                    VehicleCategories = e.EventVehicleCategories.Select(evc => new CheckBoxItem
                    {
                        Id = evc.VehicleCategoryId,
                        IsChecked = true
                    }).ToList(),
                })
                .ToList();
        }

        public async Task<EventViewModel> GetById(int id)
        {
            var eventEntity = await _context.Events
                .Include(e => e.EventVehicleCategories)
                .ThenInclude(ec => ec.VehicleCategory)
                .FirstOrDefaultAsync(e => e.Id == id);

            if (eventEntity == null) return null;

            return new EventViewModel
            {
                Id = eventEntity.Id,
                Name = eventEntity.Name,
                OrganizerId = eventEntity.OrganizerId,
                LocationId = eventEntity.LocationId,
                EventDate = eventEntity.EventDate,
                EntranceFee = eventEntity.EntranceFee,
                VehicleCategories = eventEntity.EventVehicleCategories.Select(evc => new CheckBoxItem
                {
                    Id = evc.VehicleCategoryId,
                    IsChecked = true
                }).ToList()
            };
        }

        public async Task<EventViewModel> Create(EventViewModel model)
        {
            var newEvent = new Event
            {
                Name = model.Name,
                OrganizerId = model.OrganizerId,
                LocationId = model.LocationId,
                EventDate = model.EventDate,
                EntranceFee = model.EntranceFee
            };

            _context.Events.Add(newEvent);
            await _context.SaveChangesAsync();

            var eventCategories = model.VehicleCategories
                .Where(vc => vc.IsChecked)
                .Select(vc => new EventVehicleCategory
                {
                    EventId = newEvent.Id,
                    VehicleCategoryId = vc.Id
                });

            _context.EventVehicleCategories.AddRange(eventCategories);
            await _context.SaveChangesAsync();
            return null;
        }

        public async Task<EventViewModel> Delete(int id)
        {
            var eventEntity = await _context.Events.FindAsync(id);
            if (eventEntity != null)
            {
                _context.Events.Remove(eventEntity);
                await _context.SaveChangesAsync();
            }
            return null;
        }

        public Task<EventViewModel> Update(int id, EventViewModel entity)
        {
            var eventEntity =  _context.Events
             .Include(e => e.EventVehicleCategories)
             .FirstOrDefault(e => e.Id == entity.Id);

            if (eventEntity == null)
            {
                return null;
            }
            eventEntity.Name = entity.Name;
            eventEntity.OrganizerId = entity.OrganizerId;
            eventEntity.LocationId = entity.LocationId;
            eventEntity.EventDate = entity.EventDate;
            eventEntity.EntranceFee = entity.EntranceFee;

            var existingCategories = eventEntity.EventVehicleCategories;
            _context.EventVehicleCategories.RemoveRange(existingCategories);

            var newCategories = entity.VehicleCategories
                .Where(vc => vc.IsChecked)
                .Select(vc => new EventVehicleCategory
                {
                    EventId = entity.Id,
                    VehicleCategoryId = vc.Id
                });

             _context.EventVehicleCategories.AddRangeAsync(newCategories);

             _context.SaveChangesAsync();
            return null;
        }
    }
}

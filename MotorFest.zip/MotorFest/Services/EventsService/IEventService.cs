﻿using MotorFest.Models.Event;

namespace MotorFest.Services.EventService
{
    public interface IEventService : IBasicCrudService<EventViewModel>
    {

    }
}

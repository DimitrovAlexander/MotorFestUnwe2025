﻿using MotorFest.Models.Vehicle;

namespace MotorFest.Services.VehiclesService
{
    public interface IVehicleService :IBasicCrudService<VehicleViewModel>
    {
    }
}
